package com.example.admin;

public class AdminObject {

}
